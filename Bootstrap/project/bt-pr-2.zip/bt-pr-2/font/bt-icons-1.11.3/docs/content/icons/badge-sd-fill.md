---
title: Badge SD fill
categories:
  - Badges
tags:
  - display
  - resolution
  - "standard definition"
---
