---
title: Arrow up square fill
categories:
  - Shape Arrows
tags:
  - arrow
  - square
---
