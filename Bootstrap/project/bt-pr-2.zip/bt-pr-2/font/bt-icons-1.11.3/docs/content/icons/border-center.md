---
title: Border center
categories:
  - UI and keyboard
tags:
  - borders
---
