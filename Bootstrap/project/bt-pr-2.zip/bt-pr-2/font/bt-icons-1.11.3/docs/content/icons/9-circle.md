---
title: 9 circle
categories:
  - Shapes
tags:
  - number
  - numeral
---
